package Alarma;

import java.awt.Color;
import javax.swing.JFrame;

public class Bombilla {

    private JFrame frame;

    public Bombilla() {
        frame = new JFrame("Bombilla");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(200, 200);
        frame.setVisible(true);
        Apagar();
    }

    public void Encender() {
        frame.getContentPane().setBackground(Color.red);
        System.out.println("Rojo");
    }

    public void Apagar() {
        frame.getContentPane().setBackground(Color.green);
    }

}
