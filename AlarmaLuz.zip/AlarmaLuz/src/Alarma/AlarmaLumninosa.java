package Alarma;

public class AlarmaLumninosa extends Alarma {

    Bombilla bombilla;

    public AlarmaLumninosa(Sensor sensor, Timbre timbre, Bombilla bombilla, double umbral) {

        super(sensor, timbre, umbral);
        this.bombilla = bombilla;

    }

    @Override
    public void Activar() {
        bombilla.Encender();
        super.Activar();
        System.out.println("Alarma lumninosa activada");
    }

    @Override
    public void Desactivar() {
        bombilla.Apagar();
        super.Desactivar();
        System.out.println("Alarma lumninosa desactivada");
    }
}
