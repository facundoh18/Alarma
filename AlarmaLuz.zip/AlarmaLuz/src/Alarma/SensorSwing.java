package Alarma;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SensorSwing extends Sensor implements ActionListener {

    private JFrame frame;
    private JPanel panel;
    private JButton boton;
    private JTextField editor;
    private JLabel info;

    private Alarma alarma;

    public SensorSwing() {

        frame = new JFrame("Medidor del \"grado de alarma\"");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 100);

        panel = new JPanel(new GridLayout(3, 1));


        editor = new JTextField(5);
        info = new JLabel("Valor actual... " + SwingConstants.CENTER);
        boton = new JButton("Actualizar");

        boton.addActionListener(this);


        panel.add(editor);
        panel.add(boton);
        panel.add(info);


        frame.getRootPane().setDefaultButton(boton);

        frame.getContentPane().add(panel);


        frame.setVisible(true);

    }

    public void setAlarma(Alarma alarma) {
        this.alarma = alarma;
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        setValorActual(Double.parseDouble(editor.getText()));
        info.setText("Valor Actual = " + getValorActual());
        if (alarma != null) {
            alarma.Comprobar();
        }
    }

}
