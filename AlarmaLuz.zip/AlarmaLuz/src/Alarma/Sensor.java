package Alarma;

public class Sensor {

    public Sensor() {
    }

    private double valorActual;

    public double getValorActual() {
        return valorActual;
    }

    public void setValorActual(double valorActual) {
        this.valorActual = valorActual;
    }

}
