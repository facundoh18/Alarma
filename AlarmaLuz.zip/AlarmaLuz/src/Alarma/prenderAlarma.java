package Alarma;
public class prenderAlarma {

    public static void main(String[] args) {
        
        Timbre timbre = new Timbre();
        Bombilla bombilla = new Bombilla();
        SensorSwing sensor = new SensorSwing();
        Alarma alarma = new AlarmaLumninosa(sensor, timbre, bombilla, 85);
        sensor.setAlarma(alarma);
    }
    
}
