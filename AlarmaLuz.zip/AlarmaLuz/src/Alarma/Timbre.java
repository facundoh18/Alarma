
package Alarma;

import java.awt.Toolkit;
import static java.lang.Thread.sleep;

public class Timbre {

    public static final int PITIDOS = 5;
   
    public void Activar(){
    for(int i=0; i<5; i++){
    System.out.println("activar");
    }   
    }

    public void Desactivar() {

    }
}
